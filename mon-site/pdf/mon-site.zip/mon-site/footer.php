<div class="footer" id="contact">
	<div class="container">

	<div class="footer-top">
                        <h2>Let's Get In Touch!</h2>
                    </div>
               
		<div class="row">
		<div class="col">
				<?php dynamic_sidebar( 'footer-1' ) ?>
			</div>
			<div class="col">
				<?php dynamic_sidebar( 'footer-2' ) ?>
			</div>
			<div class="col">
				<?php dynamic_sidebar( 'footer-3' ) ?>
			</div>
		</div>
	</div>

	
</div>
<footer class="footer-botom">
            <div class="container">
			<div class="social-foot">
                <div class="text-footer">
                    Copyright &copy;
                    <!-- This script automatically adds the current year to your website footer-->
                    <!-- (credit: https://updateyourfooter.com/)-->
                    <script>
                        document.write(new Date().getFullYear());
                    </script>
                </div>
            </div>
        </footer>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
