const btnMobile = document.querySelector('.btn-mobile');
const MenuMobile = document.querySelector('.main-navigation');

btnMobile.addEventListener('click', function () {
     MenuMobile.classList.toggle('active')
})
